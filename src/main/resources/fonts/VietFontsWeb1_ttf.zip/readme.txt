﻿VN.NET - UNICODE VietFonts Web Set 1
	Version 2004.04 - April 30, 2004

100% Viet Unicode & Viet Phan/Pali-Sanskrit compatible

PURPOSE
-------
Provide a base for displaying Vietnamese on the Internet and documentations.
	
FEATURES
--------
* 134 Vietnamese Glyphs per Unicode (ky' tu+. Viet trong Unicode)
* 38 Pali-Sanskrit Glyphs per Unicode (ky' tu+. Pha.n Pali-Sanskrit trong Unicode)
* float marks
* euro & VN currency symbol (ddo^`ng)
* Buddhist wheels (EE80 & EE81)

Font: VU Arial

vuArial.ttf - (normal, thu+o+`ng)
vuArialBold.ttf -(bold, dda^.m)
vuArialItalic.ttf -(italic, nghie^ng)
vuArialBoldItalic.ttf - (bold-italic, nghie^ng dda^.m)

Font: VU Times

vuTimes.ttf - (normal, thu+o+`ng)
vuTimesBold.ttf -(bold, dda^.m)
vuTimesItalic.ttf -(italic, nghie^ng)
vuTimesBoldItalic.ttf - (bold-italic, nghie^ng dda^.m)

TECHNICAL
---------

VU Arial

Ranges:   Basic Latin; Latin-1 Supplement; Latin Extended-A; Latin Extended-B; Greek; Cyrillic; Hebrew; Arabic; Latin Extended Additional; General Punctuation; Currency Symbols; Mathematical Operators; Box Drawing; Geometric Shapes; Miscellaneous Symbols; Alphabetic Presentation Forms; Arabic Presentation Forms-A; Arabic Presentation Forms-B; Unicode VietFont EE80/EE81

VU Times

Ranges:  Basic Latin; Latin-1 Supplement; Latin Extended-A; Latin Extended-B; Greek; Cyrillic; Hebrew; Arabic; Latin Extended Additional; General Punctuation; Currency Symbols; Mathematical Operators; Box Drawing; Geometric Shapes; Miscellaneous Symbols; Alphabetic Presentation Forms; Arabic Presentation Forms-A; Arabic Presentation Forms-B; Unicode VietFont EE80/EE81

CONTACTS
--------

Contact us for additional Font Sets.

PhuocHung / PhuongMai
phuochung@yahoo.com
http://www.vn.net
